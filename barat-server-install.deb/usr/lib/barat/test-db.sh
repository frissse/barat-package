#!/bin/bash

DATABASE_NAME="test-db"

which psql &>/dev/null
[ $? -eq 0 ] || echo "psql command not found."; exit 1

sudo -i -u postgres
psql
"SELECT 1 FROM pg_database WHERE datname = '$DATABASE_NAME';"
[ $? -eq 0 ] || echo "$DATABASE_NAME command not found."; exit 1